"""ProMaxRubika: an async, extensible Rubika client framework.

The built-in package does not claim to implement Rubika's private wire protocol.
A verified transport must be supplied by an official or independently validated adapter.
"""
from .client import Client
from .events import MessageEvent
from .exceptions import (
    ProMaxRubikaError, ConnectionError, AuthenticationError,
    UnsupportedFeatureError, SessionError, TransportError,
)
from . import filters

__author__ = "FAITR (@FAITR_PV)"
__version__ = "0.1.0"
__all__ = [
    "Client", "MessageEvent", "filters", "ProMaxRubikaError",
    "ConnectionError", "AuthenticationError", "UnsupportedFeatureError",
    "SessionError", "TransportError",
]
