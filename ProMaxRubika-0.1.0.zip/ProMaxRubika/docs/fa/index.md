# مستندات ProMaxRubika

سازنده: **FAITR** · کانال روبیکا: [@promaxrubika](https://rubika.ir/promaxrubika)

## وضعیت فعلی

نسخه 0.1.0 هسته Async، مدل رویداد، Handler، فیلترها و ذخیره محلی Session را ارائه می‌کند. اتصال شبکه روبیکا تا دریافت پروتکل معتبر پیاده‌سازی نشده است.

## نصب و اجرای نمونه

```bash
python -m pip install .
python examples/local_dispatch.py
```

## ثبت Handler

```python
from promaxrubika import Client, filters

app = Client(session={})

@app.on_message(filters.text)
async def handler(event):
    print(event.text)
```

برای جزئیات محدودیت‌ها، فایل `README_FA.md` را ببینید.
