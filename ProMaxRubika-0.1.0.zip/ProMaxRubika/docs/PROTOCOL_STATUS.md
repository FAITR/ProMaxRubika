# Protocol status / وضعیت پروتکل

This release intentionally contains no Rubika network implementation.

| Feature | Status in 0.1.0 |
|---|---|
| Async client lifecycle | Implemented |
| Local event dispatch | Implemented |
| Message event model | Implemented |
| Filters and handlers | Implemented |
| Local JSON session storage | Implemented |
| Rubika authentication | Not implemented |
| Live Rubika connection | Not implemented |
| Send/receive messages over Rubika | Adapter required |
| Chats, contacts, groups, channels | Adapter required |
| Media transfer | Adapter required |
| Server-side retry/rate-limit policy | Adapter required |

Do not claim network functionality until an adapter has been implemented from authoritative documentation and tested against a permitted test account.
