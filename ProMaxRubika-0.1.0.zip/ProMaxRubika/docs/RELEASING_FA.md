# راهنمای انتشار ProMaxRubika

## 1) انتشار در GitHub

1. در GitHub یک مخزن عمومی با نام `ProMaxRubika` بساز.
2. ZIP را استخراج کن و در پوشه پروژه ترمینال باز کن.
3. نام کاربری و ایمیل Git را تنظیم کن.
4. دستورات زیر را اجرا کن:

```bash
git init
git add .
git commit -m "Initial ProMaxRubika 0.1.0"
git branch -M main
git remote add origin https://github.com/FAITR/ProMaxRubika.git
git push -u origin main
```

اگر نام کاربری GitHub متفاوت است، آدرس remote را با آدرس واقعی مخزن جایگزین کن.

## 2) آماده‌سازی PyPI

- ابتدا نام `promaxrubika` را در PyPI بررسی کن؛ در صورت اشغال بودن نام، انتشار با همین نام ممکن نیست.
- مقدار ایمیل placeholder در `pyproject.toml` را با ایمیل عمومی/مناسب خودت عوض کن.
- نسخه را در `pyproject.toml` و `promaxrubika/__init__.py` هماهنگ افزایش بده.
- تست‌ها را اجرا کن و مطمئن شو هیچ Session یا اطلاعات محرمانه‌ای در بسته نیست.

```bash
python -m pip install --upgrade build twine
python -m unittest discover -s tests -v
python -m build
python -m twine check dist/*
```

ابتدا در TestPyPI آزمایش کن، سپس با حساب PyPI و ترجیحاً Trusted Publishing از GitHub Actions انتشار بده. توکن PyPI را داخل کد یا مخزن قرار نده.

## 3) نصب با pip

پس از انتشار موفق:

```bash
python -m pip install promaxrubika
```

## 4) مستندات آنلاین

برای شروع می‌توان از GitHub Pages استفاده کرد و محتوای `docs/` را منتشر کرد. برای مستندات نسخه‌دار حرفه‌ای‌تر، بعداً می‌توان MkDocs و Material for MkDocs را به‌عنوان وابستگی توسعه اضافه کرد.

## 5) پیشنهاد پست‌های کانال @promaxrubika

1. معرفی رسمی برند FAITR و هدف پروژه.
2. انتشار نسخه 0.1.0 و توضیح دقیق امکانات هسته.
3. آموزش نصب و اجرای مثال آفلاین.
4. معرفی معماری Adapter و دعوت از مشارکت‌کنندگان برای بررسی پروتکل معتبر.
5. انتشار گزارش تست‌ها و تغییرات هر نسخه.

**نکته:** تا زمانی که Adapter واقعی و تست‌شده اضافه نشده، در تبلیغات ادعای اتصال، ورود، ارسال پیام یا مدیریت گروه و کانال نکن.
