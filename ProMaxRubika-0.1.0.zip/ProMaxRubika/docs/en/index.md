# ProMaxRubika documentation

Created by **FAITR** · Official Rubika channel: [@promaxrubika](https://rubika.ir/promaxrubika)

## Current status

Version 0.1.0 provides the async core, normalized message events, handlers, filters, and local session persistence. Rubika network connectivity is not implemented until a verified protocol is available.

## Install and run

```bash
python -m pip install .
python examples/local_dispatch.py
```

## Register a handler

```python
from promaxrubika import Client, filters

app = Client(session={})

@app.on_message(filters.text)
async def handler(event):
    print(event.text)
```
